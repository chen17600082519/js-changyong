/*设置根字体*/
(function (win, doc) {
    win.onresize = function () {
        change();
    };
    change();

    function change() {
        var oFs = doc.documentElement.clientWidth / 25;
        doc.documentElement.style.fontSize = oFs + 'px';
    }
})(window, document);