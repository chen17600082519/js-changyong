function add_css(cssUrl) {
    var fileref = document.createElement("link"), list = document.getElementsByTagName("head")[0].childNodes[0];
    fileref.setAttribute("rel", "stylesheet");
    fileref.setAttribute("type", "text/css");
    fileref.setAttribute("href", cssUrl);
    if (typeof fileref != "undefined") {
        document.getElementsByTagName("head")[0].insertBefore(fileref, list);
    }
}
function add_js(get_url, func) {
    var scripts = null, xhead = document.getElementsByTagName("head")[0];
    scripts = document.createElement("script");
    scripts.type = "text/javascript";
    scripts.src = get_url;
    var browser = navigator.appName, b_version = navigator.appVersion, version = b_version.split(";"), trim_Version = version[1] ? version[1].replace(/[ ]/g, "") : null;
    if (browser == "Microsoft Internet Explorer") {
        if (typeof func === "function") {
            scripts.onreadystatechange = function () {
                var r = scripts.readyState;
                if (r === 'loaded' || r === 'complete') {
                    func.call();
                    scripts.onreadystatechange = null;
                }
            };
        }
        xhead.insertBefore(scripts);
    }
    else {
        xhead.insertBefore(scripts, xhead.firstChild);
        scripts.onload = scripts.onreadystatechange = function () {
            if (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete') {
                func.call();
            }
            scripts.onload = scripts.onreadystatechange = null;
        };
    }
}