/*
 PC端likeClass,dauqid,leyu基本模块功能
 Edition:v1.0 //2018-03-01
 author:闫亮

 --------------------------------------
 Edition:v2.0 //2018-04-20


 --------------------------------------

 */
;
(function (win, $) {
    function basic_module() {
        var self = this, ObjInitData = {
            "likeclass": "<input type=\"hidden\" id=\"LikeClass\" name=\"LikeClass\" value=\"0\">",
            "daquid": "<input type=\"hidden\" id=\"daquid\" name=\"daquid\" value=\"0\">",
            "leyuGroup": "<a href=\"javascript:void(0);\" onclick=\"javascript:doyoo.util.openChat('g=10076821');return false;\" id=\"leyuOnclick\" style=\"display:none;\">\u4E50\u8BED\u70B9\u51FB\u6309\u94AE</a>",
            "leyuUrl": "lead.soperson.com/20002054/10089553.js"
        };
        self.init.call(self, ObjInitData);
    }
    basic_module.prototype = {
        init: function (e) {
            var self = this;
            //self.fn.cookie.set("webUrl", win.location.href, 1);//设置为1天过期
            //self.render.InitAjax.apply(self, e);//Ajax请求json并执行对应方法  
            //IE8.0以下兼容bind
            if (!Function.prototype.bind) {
                Function.prototype.bind = function (oThis) {
                    if (typeof this !== "function") {
                        throw new TypeError("Function.prototype.bind - what is trying to be bound is not callable");
                    }
                    var aArgs = Array.prototype.slice.call(arguments, 1), fToBind = this, fNOP = function () { }, fBound = function () {
                        return fToBind.apply(this instanceof fNOP && oThis ? this : oThis, aArgs.concat(Array.prototype.slice.call(arguments)));
                    };
                    fNOP.prototype = this.prototype;
                    fBound.prototype = new fNOP();
                    return fBound;
                };
            }
            //IE9.0一下兼容Object.keys
            if (!Object.keys) {
                Object.keys = function (o) {
                    if (o !== Object(o))
                        throw new TypeError('Object.keys called on a non-object');
                    var k = [], p;
                    for (p in o)
                        if (Object.prototype.hasOwnProperty.call(o, p))
                            k.push(p);
                    return k;
                };
            }
            self.fn.add_css(self.constant.css.regCss); //加载注册弹窗css
            self.util.iframeTag.call(null, self); //自动加载底部iframe高度
            self.render.requestJson.call(self, e); //跨域请求json
            self.util.postLogin({ OperatingMode: "confirmlogin" }, true); //页面加载完成检测是否登陆
        },
        constant: {
            "json": {
                //url: './json/Data_wx_pc.json'
                url: "//www.zhongye.net/jsonadmin/json.asp?leixing=wxpc&v=" + new Date().getTime()
            },
            "css": {
                regCss: '/news_skin/css/bm_zhuce.css?v=' + new Date().getTime()
            },
            "htmlDom": {
                regClick: "<a href=\"javascript:void(0);\" onclick=\"javascript:ZY.util.reg();\" id=\"RegOnclick\" style=\"display:none;\">\u6CE8\u518C\u70B9\u51FB\u6309\u94AE</a>",
                regSign: "<a href=\"javascript:void(0);\" onclick=\"javascript:ZY.util.reg(true);\" id=\"RegOnSign\" style=\"display:none;\">\u767B\u5F55\u70B9\u51FB\u6309\u94AE</a>"
            },
            "bindarray": {
                0: ['data-leyu', 'leyuOnclick'],
                1: ['data-reg', 'RegOnclick'],
                2: ['data-regon', 'RegOnSign']
            },
            "MapVal": ['data-map']
        },
        fn: {
            add_css: function (cssUrl) {
                var fileref = document.createElement("link"), list = document.getElementsByTagName("head")[0].childNodes[0];
                fileref.setAttribute("rel", "stylesheet");
                fileref.setAttribute("type", "text/css");
                fileref.setAttribute("href", cssUrl);
                if (typeof fileref != "undefined") {
                    document.getElementsByTagName("head")[0].insertBefore(fileref, list);
                }
            },
            add_js: function (get_url, func) {
                var scripts = null, xhead = document.getElementsByTagName("head")[0];
                scripts = document.createElement("script");
                scripts.type = "text/javascript";
                scripts.src = get_url;
                var browser = navigator.appName, b_version = navigator.appVersion, version = b_version.split(";"), trim_Version = version[1] ? version[1].replace(/[ ]/g, "") : null;
                if (browser == "Microsoft Internet Explorer") {
                    if (typeof func === "function") {
                        scripts.onreadystatechange = function () {
                            var r = scripts.readyState;
                            if (r === 'loaded' || r === 'complete') {
                                func.call();
                                scripts.onreadystatechange = null;
                            }
                        };
                    }
                    xhead.insertBefore(scripts);
                }
                else {
                    xhead.insertBefore(scripts, xhead.firstChild);
                    scripts.onload = scripts.onreadystatechange = function () {
                        if (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete') {
                            func.call();
                        }
                        scripts.onload = scripts.onreadystatechange = null;
                    };
                }
            },
            Ajax: function () {
                var self = this, ajaxData = {
                    type: arguments[0].type || "GET",
                    url: arguments[0].url || "",
                    async: arguments[0].async || "true",
                    data: arguments[0].data || null,
                    dataType: arguments[0].dataType || "text",
                    contentType: arguments[0].contentType || "application/x-www-form-urlencoded",
                    beforeSend: arguments[0].beforeSend ||
                        function () { },
                    success: arguments[0].success ||
                        function () { },
                    error: arguments[0].error ||
                        function () { }
                };
                ajaxData.beforeSend();
                var xhr = self.createxmlHttpRequest(), responseTypeAware = 'responseType' in xhr; //ie没有此属性
                if (responseTypeAware) {
                    xhr.responseType = ajaxData.dataType;
                }
                xhr.open(ajaxData.type, ajaxData.url, ajaxData.async);
                xhr.setRequestHeader("Content-Type", ajaxData.contentType);
                xhr.send(self.convertData(ajaxData.data));
                xhr.onreadystatechange = function () {
                    if (xhr.readyState == 4) {
                        if (xhr.status == 200) {
                            if (responseTypeAware) {
                                ajaxData.success(xhr.response);
                            }
                            else {
                                ajaxData.success(self.evil(xhr.responseText));
                            }
                        }
                        else {
                            ajaxData.error();
                        }
                    }
                };
            },
            createxmlHttpRequest: function () {
                if (win.ActiveXObject) {
                    var A = null;
                    try {
                        A = new ActiveXObject("Msxml2.XMLHTTP");
                    }
                    catch (e) {
                        try {
                            A = new ActiveXObject("Microsoft.XMLHTTP");
                        }
                        catch (oc) {
                            A = null;
                        }
                    }
                    return A;
                }
                else if (win.XMLHttpRequest) {
                    return new XMLHttpRequest();
                }
            },
            convertData: function (data) {
                if (typeof data === 'object') {
                    var convertResult = "";
                    for (var c in data) {
                        convertResult += c + "=" + data[c] + "&";
                    }
                    convertResult = convertResult.substring(0, convertResult.length - 1);
                    return convertResult;
                }
                else {
                    return data;
                }
            },
            urlHref: function (e) {
                var str = location.href, strLastLen = str.lastIndexOf("/"), strIndexof = str.indexOf('//'), strVal = str.substring(strIndexof + 2, strLastLen + 1), len = str.indexOf('?'), strArray = ['.html', '.htm'];
                if (len > -1) {
                    strVal = str.substring(strIndexof + 2, len);
                }
                for (var i = 0; i < strArray.length; i++) {
                    var strPar = str.indexOf(strArray[i]);
                    if (strPar > -1) {
                        var s = str.substring(strIndexof + 2, strPar + strArray[i].length);
                        if (len > -1) {
                            if (strVal == e) {
                                return 0;
                            }
                            else {
                                return -1;
                            }
                        }
                        else {
                            if (s == e) {
                                return 0;
                            }
                            else {
                                return -1;
                            }
                        }
                    }
                    else {
                        if (strVal == e) {
                            return 0;
                        }
                        else {
                            return -1;
                        }
                    }
                }
            },
            parseDom: function (arg) {
                var objE = document.createElement("div"), domArray = '';
                for (var i = 0; i < arg.length; i++) {
                    domArray += "" + arg[i];
                }
                objE.innerHTML = domArray;
                return objE.childNodes;
            },
            evil: function (fn) {
                var Fn = Function;
                return new Fn('return ' + fn)();
            },
            includeJs: function (path) {
                var a = document.createElement("script");
                a.type = "text/javascript";
                a.src = path;
                var head = document.getElementsByTagName("head")[0];
                head.appendChild(a);
                //下列方法会导致后续的函数调用失效，他会把加载完成后的JS删除掉
                // var head = document.getElementsByTagName("head")[0];
                // var script = document.createElement("script");
                // script.src = path;
                // var done = false;
                // script.onload = script.onreadystatechange = function () {
                //     if (!done && (!this.readyState || this.readyState == "loaded" || this.readyState == "complete")) {
                //         done = true;
                //         script.onload = script.onreadystatechange = null;
                //         head.removeChild(script);
                //     }
                // };
                // head.appendChild(script);
            },
            hover_tc_net: function (n) {
                var self = this, liLength = document.getElementById("tab_bm_").getElementsByTagName("li").length;
                for (var i = 1; i <= liLength; i++) {
                    self.g('tab_bm_' + i).className = 'nor_tc';
                    self.g('tab_bm_0' + i).className = 'undis_tc_net';
                }
                self.g('tab_bm_0' + n).className = 'dis_tc_net';
                self.g('tab_bm_' + n).className = 'nav_ys' + n + ' hovertab_bm';
            },
            g: function (o) {
                return document.getElementById(o);
            },
            cookie: {
                set: function (key, val, time) {
                    var date = new Date(); //获取当前时间
                    var expiresDays = time; //将date设置为n天以后的时间
                    date.setTime(date.getTime() + expiresDays * 24 * 3600 * 1000); //格式化为cookie识别的时间
                    document.cookie = key + "=" + val + ";expires=" + date.toGMTString(); //设置cookie
                },
                get: function (key) {
                    /*获取cookie参数*/
                    var getCookie = document.cookie.replace(/[ ]/g, ""); //获取cookie，并且将获得的cookie格式化，去掉空格字符
                    var arrCookie = getCookie.split(";"); //将获得的cookie以"分号"为标识 将cookie保存到arrCookie的数组中
                    var tips; //声明变量tips
                    for (var i = 0; i < arrCookie.length; i++) {
                        var arr = arrCookie[i].split("="); //将单条cookie用"等号"为标识，将单条cookie保存为arr数组
                        if (key == arr[0]) {
                            tips = arr[1]; //将cookie的值赋给变量tips
                            break; //终止for循环遍历
                        }
                    }
                    return tips;
                },
                Deletes: function (keys) {
                    var dates = new Date(); //获取当前时间
                    dates.setTime(dates.getTime() - 10000); //将date设置为过去的时间
                    document.cookie = keys + "=v; expires =" + dates.toGMTString(); //设置cookie
                }
            },
            oUrl: function (urls, fn) {
                var s = window.location.search.substr(0), u = urls, v, code;
                u.indexOf('|') > -1 ?
                    (v = u.split("|")[0],
                        code = "<a href=\"" + v + "\" id=\"aWinBlank\" target=\"_blank\" style=\"display:none;\">\u65B0\u7A97\u53E3\u6A21\u62DF\u70B9\u51FB</a>",
                        ZY.render.addHtml([code], ZY),
                        fn.call(this, 'aWinBlank')) :
                    fn.call(this, u + s);
            }
        },
        util: {
            onCheckPhone: function (fromId, texts, url, state) {
                var MOBILE_REG = /^[1][0-9]{10}$/, value = $(fromId + " input[name='Telephone']").val(), like_class = document.getElementById("LikeClass").value, daqu_id = document.getElementById("daquid").value, oUrlHref = null;
                if (url !== undefined && url !== null) {
                    ZY.fn.oUrl(url, function (e) {
                        oUrlHref = e;
                    });
                }
                if (MOBILE_REG.test(value)) {
                    if (oUrlHref == "aWinBlank") {
                        $.ajaxSetup({ async: false });
                    }
                    $.post("/AjaxControls/AjaxLoginPage.ashx?times=" + new Date().getTime() + "&UserName=" + value, {
                        Telephone: value,
                        OperatingMode: "register",
                        RegCode: "",
                        Password: 123456,
                        Source: 3,
                        Email: "",
                        LikeClass: like_class,
                        daquid: daqu_id,
                        PageType: 1,
                        ts: 1,
                        jianjie: "\u5927\u533AID\uFF1A" + daqu_id + " | \u6D4F\u89C8\u5668\u4FE1\u606F\uFF1A" + navigator.userAgent
                    }, function (data) {
                        if (data != null) {
                            if (data.success == "1") {
                                if (texts !== undefined) {
                                    if (texts.replace(/\s+/g, "").length > 0) {
                                        if (texts !== 'null') {
                                            if (texts.indexOf('<div') > -1) {
                                                $('body').before(texts);
                                            }
                                            else if (texts.indexOf('data-js:') > -1) {
                                                var domString = texts.split('|')[0].substr(texts.indexOf('data-js:') + 8, texts.split('|')[0].length);
                                                new Function('return ' + domString)();
                                                if (texts.indexOf('|') > -1) {
                                                    new Function('return ' + texts.split('|')[1])();
                                                }
                                            }
                                            else {
                                                alert(texts);
                                            }
                                        }
                                    }
                                    else {
                                        alert("提交成功！");
                                    }
                                    if (url !== undefined && url !== null) {
                                        oUrlHref !== "aWinBlank" ?
                                            win.location.href = oUrlHref :
                                            document.getElementById(oUrlHref).click();
                                    }
                                }
                                else {
                                    alert("提交成功！");
                                }
                            }
                            else if (data.result != null) {
                                if (data.success == "0") {
                                    if (state !== undefined) {
                                        if (state.replace(/\s+/g, "").length > 0 && state.indexOf('true') > -1) {
                                            if (url !== undefined && url !== null) {
                                                oUrlHref !== "aWinBlank" ?
                                                    win.location.href = oUrlHref :
                                                    document.getElementById(oUrlHref).click();
                                            }
                                        }
                                        else {
                                            alert(data.result);
                                        }
                                    }
                                    else {
                                        alert(data.result);
                                    }
                                }
                                else {
                                    alert(data.result);
                                }
                            }
                        }
                        return false;
                    }, "json");
                }
                else {
                    alert("手机号格式不正确！");
                    $(fromId + " input[name='Telephone']").focus();
                    return false;
                }
            },
            iframeheights: function () {
                var event = arguments.callee.caller.arguments[0] || win.event;
                var ele = event.target || event.srcElement, idName = ele.getAttribute("id"), ifm = document.getElementById(idName), subWeb = win.frames[idName].document || ifm.contentWindow.document;
                if (ifm != null && subWeb != null) {
                    setTimeout(function () {
                        ifm.height = subWeb.body.scrollHeight;
                    }, 50);
                }
            },
            iframeTag: function (self) {
                var tagName = win.parent.document.getElementsByTagName('iframe');
                for (var k = 0; k < tagName.length; k++) {
                    if (tagName[k].getAttribute('data-iframe') !== null) {
                        self.util.iframeId(tagName[k].getAttribute('id'));
                    }
                }
            },
            iframeId: function (idName) {
                var ifm = document.getElementById(idName);
                $(ifm).load(function () {
                    var subWeb = win.frames[idName].document || ifm.contentWindow.document;
                    if (ifm != null && subWeb != null) {
                        ifm.height = subWeb.body.scrollHeight;
                    }
                });
            },
            reg: function () {
                var self = this;
                if ($("#BmReg").length > 0 && $("#regfade").length > 0) {
                    $("#BmReg").remove();
                    $("#regfade").remove();
                }
                $('body').append("<div id=\"BmReg\"class=\"bm_xzc\"><a href=\"javascript:void(0);\"alt=\"close\"class=\"closep\"><img src=\"//www.zhongye.net/news_skin/images/kszhuce/cha.png\"class=\"btn_close\"title=\"Close Window\"alt=\"Close\"/></a><div class=\"xtc_nwd\">\u5341\u79D2\u949F\u52A0\u5165\u4E2D\u4E1A\uFF0C\u5206\u4EAB\u66F4\u591A\u8003\u8BD5\u8D44\u8BAF</div><div id=\"Bmquickdiv\"><div class=\"tc_net\"><div id=\"tab_bm_\"class=\"tab_bm_\"><ul><li id=\"tab_bm_1\"class=\"nav_ys1 hovertab_bm\"onclick=\"javascript:ZY.fn.hover_tc_net(1);\"><i></i>&nbsp;&nbsp;&nbsp;&nbsp;\u6CE8\u518C</li><li id=\"tab_bm_2\"class=\"nor_tc\"onclick=\"javascript:ZY.fn.hover_tc_net(2);\"><i></i>&nbsp;&nbsp;&nbsp;&nbsp;\u5DF2\u6709\u8D26\u53F7\u767B\u5F55</li></ul></div><div class=\"ctt_tc_net\"><div class=\"dis_tc_net\"id=\"tab_bm_01\"><div class=\"Bm_yl_tcxqhnr\"><ul><li><span><i>*</i>\u624B\u673A\u53F7\u7801</span><span><input type=\"text\"id=\"bm_username\"name=\"Telephone\"value=\"\"placeholder=\"\u8BF7\u8F93\u5165\u60A8\u7684\u624B\u673A\u53F7\"class=\"tc_tel\"/></span></li><li class=\"Bm_tc_tslidl\"><span><i>*</i><b>\u5BC6&#12288;&#12288;\u7801</b></span><span><input type=\"password\"id=\"bm_pwd\"name=\"Password\"value=\"\"placeholder=\"\u8BF7\u8F93\u5165\u60A8\u7684\u5BC6\u7801\"class=\"Bm_tc_pass Bm_pas_x\"/></span><dl><b class=\"tc_state\">\u5F31</b><b>\u4E2D</b><b>\u5F3A</b></dl></li><li><span><i>*</i>\u786E\u8BA4\u5BC6\u7801</span><span><input type=\"password\"id=\"BmConfirm\"name=\"BmConfirm\"value=\"\"placeholder=\"\u8BF7\u8F93\u5165\u60A8\u7684\u786E\u8BA4\u5BC6\u7801\"class=\"Bm_tc_pass\"/></span></li><li class=\"tc_tsli\"><div class=\"tc_xieyi\"><i></i><label><input name=\"checkbox\"type=\"checkbox\"value=\"checkbox\"checked=\"checked\"/>\u5DF2\u9605\u8BFB\u5E76\u540C\u610F</label>&nbsp;&nbsp;<a href=\"/help/zhuce.html\"target=\"_blank\">\u300A\u4E2D\u4E1A\u7F51\u6821\u670D\u52A1\u534F\u8BAE\u300B</a></div><input type=\"button\"value=\"\u6CE8\u518C\"id=\"bm_regbutton\"/></li></ul></div></div><div class=\"undis_tc_net\"id=\"tab_bm_02\"><div class=\"Bm_yl_tcxqhnr\"><ul><li><span><i>*</i>\u624B\u673A\u53F7\u7801</span><span><input type=\"text\"id=\"txtname\"name=\"username\"value=\"\"class=\"tc_tel\"placeholder=\"\u8BF7\u8F93\u5165\u60A8\u7684\u624B\u673A\u53F7\"/></span></li><li><span><i>*</i><b>\u5BC6&#12288;&#12288;\u7801</b></span><span><input type=\"password\"id=\"txtpass\"name=\"password\"value=\"\"class=\"Bm_tc_pass Bm_pas_x\"placeholder=\"\u8BF7\u8F93\u5165\u60A8\u7684\u5BC6\u7801\"/></span></li><li class=\"tc_tsli2\"><dl class=\"tc_denglu\"><i></i><label><input name=\"autologin\"type=\"checkbox\"id=\"autologin\"value=\"auto\"checked=\"checked\">\u4E0B\u6B21\u81EA\u52A8\u767B\u5F55</label><b><a href=\"/forgotpassword.aspx\"target=\"_blank\">\u627E\u56DE\u5BC6\u7801\uFF1F</a></b></dl><input type=\"button\"value=\"\u767B\u5F55\"id=\"Bm_loginBtn\"/></li></ul></div></div></div></div></div><div class=\"yl_tcxok\"id=\"Bmsuccess\"><dl><img src=\"/news_skin/images/kszhuce/ok_yuan.jpg\"/></dl><span class=\"regOkFont\">\u606D\u559C\u60A8\uFF0C\u6CE8\u518C\u6210\u529F\uFF01</span><div class=\"yl_xtcanx\"><a href=\"javascript:void(0);\"class=\"yl_tc_xan1\"onclick=\"javascript:$(&#39;#regfade,.bm_xzc&#39;).fadeOut();ZY.util.postLogin({OperatingMode:'confirmlogin' }, true);\">\u505C\u7559\u5728\u5F53\u524D\u9875</a><a href=\"/usercenter/\"class=\"yl_tc_xan2\">\u5230\u4F1A\u5458\u4E2D\u5FC3\u542C\u8BFE</a></div></div></div>");
                $('body').append('<div id="regfade"></div>');
                $('#regfade').css({
                    'filter': 'alpha(opacity=80)',
                    'background': '#000',
                    'position': 'fixed',
                    'left': '0',
                    'top': '0',
                    'z-index': '10',
                    'width': '100%',
                    'height': '100%',
                    'z-index': '9999',
                    'opacity': '.80'
                }).fadeIn();
                $('#BmReg').fadeIn().css({
                    'width': '490px'
                }).prepend();
                $("#Bmquickdiv").show();
                $("#Bmsuccess").hide();
                var popMargTop = ($('#BmReg').height() + 80) / 2;
                var popMargLeft = ($('#BmReg').width() + 80) / 2;
                $('#BmReg').css({
                    'margin-top': -popMargTop,
                    'margin-left': -popMargLeft
                });
                //当前点击是否是登录按钮
                var zhuceValArg = arguments[0];
                zhuceValArg == true ? $('#tab_bm_2').click() : $('#tab_bm_1').click();
                //是否登陆
                if (self.isLogin()) {
                    $("#Bmquickdiv").hide();
                    $("#Bmsuccess").show();
                    $('#BmReg').fadeIn().css({
                        'width': '490px'
                    }).prepend();
                }
                //点击关闭注册弹窗
                $(document).on('click', 'a.closep', function () {
                    self.postLogin({ OperatingMode: "confirmlogin" }, true);
                    $('#regfade,.bm_xzc').fadeOut();
                    return false;
                });
                //点击退出登录处理事件
                // $("#logonOut").click(function () {
                //     self.postLogin({ OperatingMode: "logonOut" }, false);
                // });
                //点击登陆处理事件
                var username_errinfo = false;
                var password_errinfo = false;
                var checkcode_errinfo = false;
                $(document).off("click", '#Bm_loginBtn').on('click', '#Bm_loginBtn', function () {
                    self.ValidateUserName();
                    self.ValidatePassword();
                    if (!username_errinfo && !password_errinfo) {
                        self.postLoginButton({ OperatingMode: "login", UserName: $("#txtname").val(), Password: $("#txtpass").val(), CheckCode: "", autoLogin: $("#autologin").attr("checked") == null ? "" : "checked", time: new Date().getTime() });
                    }
                });
                //点击注册处理事件
                $(document).off("click", '#bm_regbutton').on('click', '#bm_regbutton', function () {
                    var username = document.getElementById("bm_username").value;
                    var user = document.getElementById("bm_username").value.length;
                    var password = document.getElementById("bm_pwd").value;
                    var myreg = /^[1][0-9]{10}$/;
                    var con_password = document.getElementById("BmConfirm").value;
                    if (con_password !== password) {
                        alert("您两次输入的密码不正确!");
                        document.getElementById("BmConfirm").focus();
                        return false;
                    }
                    if (!user || user == null || user != 11 || user == 0) {
                        alert("请输入有效的手机号码!");
                        document.getElementById("bm_username").focus();
                        return false;
                    }
                    if (!myreg.test(username)) {
                        alert('请输入有效的手机号码！');
                        document.getElementById("bm_username").focus();
                        return false;
                    }
                    if (!password.length || password.length == null || password.length == 0) {
                        alert("请输入您的密码!");
                        document.getElementById("bm_pwd").focus();
                        return false;
                    }
                    if (password.indexOf(" ") != -1) {
                        alert("密码不允许有空格！");
                        return false;
                    }
                    if ($("#bm_username").val().length > 0) {
                        $("#bm_regbutton").attr({
                            'disabled': true,
                            'class': 'grayscale'
                        });
                        var likeClass = $("#LikeClass").val() == null ? 0 : $("#LikeClass").val(), daquId = $("#daquid").val() == null ? 0 : $("#daquid").val();
                        $.post("/AjaxControls/AjaxLoginPage.ashx", {
                            OperatingMode: "register", UserName: $("#bm_username").val(), RegCode: "", Password: $("#bm_pwd").val(), Email: "", Telephone: $("#bm_username").val(), LikeClass: likeClass, daquid: daquId, PageType: 1, ts: 1,
                            jianjie: "\u5927\u533AID\uFF1A" + daquId + " | \u6D4F\u89C8\u5668\u4FE1\u606F\uFF1A" + navigator.userAgent
                        }, function (data) {
                            if (data != null) {
                                if (data.success == "1") {
                                    $("#bm_regbutton").attr({
                                        'disabled': false,
                                        'class': 'yl_x_bottom'
                                    });
                                    $("#Bmquickdiv").hide();
                                    $("#Bmsuccess").show();
                                    self.postLogin({ OperatingMode: "confirmlogin" }, true);
                                }
                                else if (data.result != null) {
                                    alert(data.result);
                                    $("#bm_regbutton").attr({
                                        'disabled': false,
                                        'class': 'yl_x_bottom'
                                    });
                                    return false;
                                }
                            }
                            return false;
                        }, "json");
                    }
                });
                //密码强度检测 $('#bm_pwd').keyup
                $(document).on('keyup', '#bm_pwd', function (e) {
                    var strongRegex = new RegExp("^(?=.{8,})(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*\\W)|^(?=.{8,})((?=.*[a-z])(?=.*[0-9])(?=.*\\W)).*$|((?=.{8,})(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9]).*$)", "g");
                    var mediumRegex = new RegExp("^(?=.{7,})(((?=.*[A-Z])(?=.*[a-z]))|((?=.*[A-Z])(?=.*[0-9]))|((?=.*[a-z])(?=.*[0-9]))).*$", "g");
                    var enoughRegex = new RegExp("(?=.{6,}).*", "g");
                    if (false == enoughRegex.test($(this).val())) {
                        $(".Bm_tc_tslidl dl b").removeClass("tc_state");
                        $(".Bm_tc_tslidl dl b").eq(0).attr("class", "tc_state");
                    }
                    else if (strongRegex.test($(this).val())) {
                        $(".Bm_tc_tslidl dl b").removeClass("tc_state");
                        $(".Bm_tc_tslidl dl b").eq(2).attr("class", "tc_state");
                    }
                    else if (mediumRegex.test($(this).val())) {
                        $(".Bm_tc_tslidl dl b").removeClass("tc_state");
                        $(".Bm_tc_tslidl dl b").eq(1).attr("class", "tc_state");
                    }
                    else {
                        $(".Bm_tc_tslidl dl b").removeClass("tc_state");
                        $(".Bm_tc_tslidl dl b").eq(0).attr("class", "tc_state");
                    }
                });
            },
            isLogin: function () {
                var islogin = false;
                $.ajax({
                    type: "GET",
                    async: false,
                    url: "/AjaxControls/AjaxLoginPage.ashx?OperatingMode=confirmlogin",
                    dataType: "json",
                    success: function (data) {
                        if (data != null && data.result == "ok") {
                            islogin = true;
                        }
                        else if (data != null && data.result != "nouser") {
                            islogin = false;
                        }
                        else {
                            islogin = false;
                        }
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                        alert(errorThrown);
                        return false;
                    }
                });
                return islogin;
            },
            postLogin: function (obj, isShow) {
                $.ajax({
                    type: "POST",
                    url: "/AjaxControls/AjaxLoginPage.ashx?v=" + new Date().getTime(),
                    data: obj,
                    dataType: "json",
                    success: function (data) {
                        if (data != null && data.result == "ok") {
                            if (isShow) {
                                $("#loginwin").hide();
                                $("#logininfowin").show();
                                $("#l_username").html(data.username);
                            }
                            else {
                                $("#logininfowin").hide();
                                $("#loginwin").show();
                            }
                        }
                        else if (data != null && data.result != "nouser") {
                            $("#logininfowin").hide();
                            $("#loginwin").show();
                        }
                        return false;
                    }
                });
                // $.post("/AjaxControls/AjaxLoginPage.ashx?v=" + new Date().getTime(), obj,
                //     function (data) {
                //         if (data != null && data.result == "ok") {
                //             if (isShow) {
                //                 $("#loginwin").hide();
                //                 $("#logininfowin").show();
                //                 $("#l_username").html(data.username);
                //             } else {
                //                 $("#logininfowin").hide();
                //                 $("#loginwin").show();
                //             }
                //         } else if (data != null && data.result != "nouser") {
                //             $("#logininfowin").hide();
                //             $("#loginwin").show();
                //         }
                //         return false;
                //     }, "json");
            },
            ValidateUserName: function () {
                var username = $('#txtname').val();
                if (username.length == 0) {
                    $('#txtname').css('background', "#F5F5F5");
                    username_errinfo = true;
                }
                else {
                    $('#txtname').css('background', "white");
                    username_errinfo = false;
                }
            },
            ValidatePassword: function () {
                var password = $('#txtpass').val();
                if (password.length == 0) {
                    $('#txtpass').css('background', "#F5F5F5");
                    password_errinfo = true;
                }
                else {
                    $('#txtpass').css('background', "white");
                    password_errinfo = false;
                }
            },
            postLoginButton: function (obj) {
                $.post("/AjaxControls/AjaxLoginPage.ashx", obj, function (data) {
                    if (data != null && data.result == "ok") {
                        $('.regOkFont').html('登录成功！');
                        $('#Bmquickdiv').hide();
                        $('#Bmsuccess').show();
                    }
                    else if (data != null && data.result != null) {
                        alert(data.result);
                        return false;
                    }
                    return false;
                }, "json");
            },
            returnTop: function (number) {
                var v = $(document).scrollTop();
                v > 0 ? ($('html,body').animate({ scrollTop: 0 }, number !== undefined ? number : 300)) : '';
            }
        },
        render: {
            InitAjax: function (ObjInitData) {
                var self = this;
                self.fn.Ajax({
                    type: "GET",
                    async: true,
                    url: self.constant.json.url + "?v=" + new Date().getTime(),
                    dataType: "json",
                    data: {
                        "v": new Date().getTime()
                    },
                    beforeSend: function () { },
                    success: function (e) {
                        var eObj = e['DataObj'], eLen = eObj.length, i = 0;
                        for (; i < eLen; i++) {
                            var o = eObj[i];
                            if (self.fn.urlHref(o.url) > -1) {
                                ObjInitData = {
                                    likeclass: "<input type=\"hidden\" id=\"LikeClass\" name=\"LikeClass\" value=\"" + o.likeClassId + "\">",
                                    daquid: "<input type=\"hidden\" id=\"daquid\" name=\"daquid\" value=\"" + o.daquId + "\">",
                                    leyuGroup: "<a href=\"javascript:void(0);\" onclick=\"javascript:doyoo.util.openChat('g=" + (o.leyuGroupId ? o.leyuGroupId : null) + "');return false;\" id=\"leyuOnclick\" style=\"display:none;\">\u4E50\u8BED\u70B9\u51FB\u6309\u94AE</a>",
                                    leyuUrl: "lead.soperson.com/20002054/" + (o.leyuId ? o.leyuId : null) + ".js"
                                };
                                //self.fn.includeJs(ObjInitData.curr.leyuUrl);//添加到head底部(乐语不支持异步，故此放弃)
                                self.render.addHtml([ObjInitData.likeclass, ObjInitData.daquid, ObjInitData.leyuGroup, self.constant.htmlDom.regClick, self.constant.htmlDom.regSign], self); //添加到body头部
                                self.render.bindClickFn(self); //绑定乐语和注册模拟点击
                                self.render.testLeyuid(ObjInitData.leyuUrl); //检测页面是否存在乐语JS 
                            }
                        }
                    }
                });
            },
            requestJson: function (ObjInitData) {
                var self = this;
                self.fn.add_js(self.constant.json.url, function () {
                    var e = callbackJson, eObj = e['DataObj'], eLen = 
                    peObj.length, i = 0, match = false;
                    self.render.bindMap(self.constant.MapVal); //MapVal锚点跳转
                    self.render.bindClickFn(self); //绑定乐语和注册模拟点击                    
                    self.render.addHtml([ObjInitData.likeclass, ObjInitData.daquid, ObjInitData.leyuGroup, self.constant.htmlDom.regClick, self.constant.htmlDom.regSign], self); //默认参数先行添加到body头部
                    for (; i < eLen; i++) {
                        var o = eObj[i];
                        if (self.fn.urlHref(o.url) > -1) {
                            match = true;
                            ObjInitData = {
                                likeclass: "<input type=\"hidden\" id=\"LikeClass\" name=\"LikeClass\" value=\"" + o.likeClassId + "\">",
                                daquid: "<input type=\"hidden\" id=\"daquid\" name=\"daquid\" value=\"" + o.daquId + "\">",
                                leyuGroup: "<a href=\"javascript:void(0);\" onclick=\"javascript:doyoo.util.openChat('g=" + (o.leyuGroupId ? o.leyuGroupId : null) + "');return false;\" id=\"leyuOnclick\" style=\"display:none;\">\u4E50\u8BED\u70B9\u51FB\u6309\u94AE</a>",
                                leyuUrl: "lead.soperson.com/20002054/" + (o.leyuId ? o.leyuId : null) + ".js"
                            };
                            //self.fn.includeJs(ObjInitData.curr.leyuUrl);//添加到head底部(乐语不支持异步，故此放弃)
                            self.render.addHtml([ObjInitData.likeclass, ObjInitData.daquid, ObjInitData.leyuGroup, self.constant.htmlDom.regClick, self.constant.htmlDom.regSign], self); //实际参数添加到body头部                            
                            self.render.testLeyuid(ObjInitData.leyuUrl); //检测页面是否存在乐语JS
                        }
                    }
                    match == false ? (console.log('没有匹配到此URL地址！')) : '';
                });
            },
            addHtml: function (ArraySrc, self) {
                var doc = document.body || document.documentElement, arglen = ArraySrc.length, first = doc.firstChild; //得到页面的第一个元素                               
                for (var i = 0; i < arglen; i++) {
                    var vid = self.fn.parseDom(ArraySrc)[i].getAttribute("id"), docVid = document.getElementById(vid);
                    if (docVid) {
                        docVid.parentNode.removeChild(docVid);
                        doc = document.body || document.documentElement,
                            arglen = ArraySrc.length,
                            first = doc.firstChild; //得到页面的第一个元素 
                        doc.insertBefore(self.fn.parseDom(ArraySrc)[i], first);
                    }
                    else {
                        doc.insertBefore(self.fn.parseDom(ArraySrc)[i], first);
                    }
                }
            },
            bindClick: function (ArrayVal) {
                var tagName = win.parent.document.getElementsByTagName('*');
                for (var k = 0; k < tagName.length; k++) {
                    if (tagName[k].getAttribute(ArrayVal[0]) !== null) {
                        tagName[k].onclick = function () {
                            var evt = arguments.callee.arguments[0] || win.event; //获取event对象
                            if (evt.preventDefault) {
                                evt.preventDefault(); //非IE浏览器
                            }
                            else {
                                evt.returnValue = false; //在早期的IE版本中
                            }
                            evt.stopPropagation ? evt.stopPropagation() : (evt.cancelBubble = true);
                            document.getElementById(ArrayVal[1]).onclick();
                        };
                    }
                }
            },
            bindClickFn: function (t) {
                for (var j = 0; j < Object.keys(t.constant.bindarray).length; j++) {
                    t.render.bindClick(t.constant.bindarray[j]); //绑定乐语和注册模拟点击
                }
            },
            testLeyuid: function (e) {
                var tagName = win.parent.document.getElementsByTagName('script'), value = null;
                for (var k = 0; k < tagName.length; k++) {
                    if (tagName[k].outerHTML.indexOf(e) > -1) {
                        value = true;
                        break;
                    }
                }
                value == null ? (console.log('乐语ID检测不通过，请检查乐语是否错误！')) : '';
            },
            bindMap: function (MapVal) {
                var self = this, tagName = win.parent.document.getElementsByTagName('*');
                for (var k = 0; k < tagName.length; k++) {
                    if (tagName[k].getAttribute(MapVal[0]) !== null) {
                        var mapValText = tagName[k].getAttribute(MapVal[0]).split(','), mapId = mapValText[0], mapNum = mapValText[1];
                        tagName[k].onclick = function (mapId, mapNum) {
                            var mao = $('#' + mapId);
                            if (mao.length > 0) {
                                var pos = mao.offset().top;
                                $("html,body").animate({ scrollTop: pos - 10 - (mapNum !== undefined ? mapNum : 0) }, 300);
                            }
                        }.bind(this, mapId, mapNum);
                        // tagName[k].onclick = function () {
                        //     var evt = evt || win.event; //获取event对象
                        //     if (evt.preventDefault) {
                        //         evt.preventDefault(); //非IE浏览器
                        //     }
                        //     else {
                        //         evt.returnValue = false; //在早期的IE版本中
                        //     }
                        //     event.stopPropagation ? event.stopPropagation() : (event.cancelBubble = true);
                        // };
                    }
                }
            },
            onMap: function (id) {
                var mao = $('#' + id);
                if (mao.length > 0) {
                    var pos = mao.offset().top;
                    $("html,body").animate({ scrollTop: pos - 10 }, 300);
                }
            }
        }
    };
    win.ZY = new basic_module();
    win.console = win.console || (function () {
        var c = {};
        c.log = c.warn = c.debug = c.info = c.error = c.time = c.dir = c.profile
            = c.clear = c.exception = c.trace = c.assert = function () { };
        return c;
    })();
})(window, $);