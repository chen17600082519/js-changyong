;
(function (win, $) {
    function activity(obj) {
        this.init(obj);
    };
    activity.prototype = {
        init: function (obj) {
            this.data = obj;
            this.fun.new_addbanner.call(this);
            this.fun.banxing.call(this)
        },

        //数据部分放放在new的时候传入，默认为null
        data: null,
        //功能部分
        fun: {
            //动态添加活动class
            add_css: function (self) {
                //console.log(self);
                var url = window.location.href
                //这里需要注意，需要做一个判断，如果页面含有在url中传入的特定参数，就需要判断添加css的时候是否带按钮
                if (url.indexOf('parameter=leyu11') > -1) {
                    $(".spring").css({
                        "height": self.data.hei + "px",
                        "backgroundImage": "url(//bj.zhongye.net/active/img/PC1-" + self.data.hei + ".jpg)",
                        "backgroundRepeat": "no-repeat",
                        "backgroundSize": "1920px " + self.data.hei + "px",
                        "backgroundPosition": "center center",
                        'cursor': 'pointer'
                    });
                } else {
                    $(".spring").css({
                        "height": self.data.hei + "px",
                        "backgroundImage": "url(//bj.zhongye.net/active/img/PC-" + self.data.hei + ".jpg)",
                        "backgroundRepeat": "no-repeat",
                        "backgroundSize": "1920px " + self.data.hei + "px",
                        "backgroundPosition": "center center",
                        'cursor': 'pointer'
                    });
                }
                $(".spring .wrapper").css({
                    "width": "1050px",
                    "margin": "0 auto",
                    "position": "relative"
                });
            },
            //轮播执行代码
            springflex: function () {
                //首图切换
                var flexSlider = document.querySelector(".flexslider") || this.getByClassName("flexslider")[0], //兼容dom不存在报错
                    jqFlexSlider = this.getByClassName("", "jquery.flexslider-min.js")[0], //兼容JS不存在报错
                    loopCount = 0;
                jqFlexSlider && flexSlider && $('.flexslider').flexslider({ //只有都存在才会执行后边 flexslider 方法
                    directionNav: true,
                    pauseOnAction: false,
                    animationLoop: true,
                    slideshowSpeed: 5000,
                    after: function (slider) {
                        if (slider.currentSlide == 0) {
                            slider.pause();
                            setTimeout(function () {
                                slider.play();
                            }, 5000);
                        }
                    },
                    start: function (slider) {
                        loopCount++;
                        if (slider.currentSlide == 0 && loopCount == 1) {
                            slider.pause();
                            setTimeout(function () {
                                slider.play();
                            }, 5000);
                        }

                    }
                });
            },
            //轮播图兼容性
            getByClassName: function (ClassName, JsName) {
                if (JsName) {
                    var aEle = document.getElementsByTagName('script');
                    var arr = [];
                    for (var i = 0; i < aEle.length; i++) {
                        if (aEle[i].src.indexOf(JsName) > -1) {
                            arr.push(aEle[i]);
                        }
                    }
                    return arr;
                } else {
                    if (document.getElementsByClassName) {
                        return document.getElementsByClassName(ClassName);
                    } else {
                        var aEle = document.getElementsByTagName('*');
                        var arr = [];
                        for (var i = 0; i < aEle.length; i++) {
                            if (aEle[i].className == ClassName) {
                                arr.push(aEle[i]);
                            }
                        }
                        return arr;
                    }
                }
            },
            //跨域请求jsonp
            get_js: function (get_url, fn) {
                var script = null,
                    xhead = document.getElementsByTagName("head")[0];
                script = document.createElement("script");
                script.type = "text/javascript";
                script.src = get_url;
                var browser = navigator.appName,
                    b_version = navigator.appVersion,
                    version = b_version.split(";"),
                    trim_Version = version[1] ? version[1].replace(/[ ]/g, "") : null;
                if (browser == "Microsoft Internet Explorer" && trim_Version == "MSIE6.0" || browser == "Microsoft Internet Explorer" && trim_Version == "MSIE7.0" || browser == "Microsoft Internet Explorer" && trim_Version == "MSIE8.0" || browser == "Microsoft Internet Explorer" && trim_Version == "MSIE9.0") {
                    if (typeof fn === "function") {
                        script.onreadystatechange = function () {
                            var r = script.readyState;
                            if (r === 'loaded' || r === 'complete') {
                                fn.call();
                            }
                        };
                    }
                    xhead.insertBefore(script);
                } else {
                    xhead.insertBefore(script, xhead.firstChild);
                    script.onload = script.onreadystatechange = function () {
                        if (!this.readyState || this.readyState == 'loaded' || this.readyState == 'complete') {
                            fn.call();
                        }
                        script.onload = script.onreadystatechange = null;
                    }
                }
            },
            //添加统一横幅
            unified_banner: function (num, position, divHengfu, divAlert) {
                //首先根据传过来的num去获取插入横幅的位置
                var n = $("body").children("div").eq(num);
                //console.log(n);
                //这个位置需要注意有时候页面中的横幅偏上或者偏下，导致横幅位置不正常，需要根据特定页面去跟换num
                if (this.urlHref('bj.zhongye.net/zsjz/pz/zixun/baidu/') > -1 || this.urlHref('bj.zhongye.net/bj_gkgwy_sem_pc/') > -1) {
                    var n = $("body").children("div").eq(num + 1);
                }
                //判断是插入在之前还是之后
                if (position === 'before') {
                    n.before(divHengfu);
                    n.before(divAlert);
                } else {
                    n.after(divHengfu);
                    n.after(divAlert);
                }
            },
            //添加轮播html
            add_html: function (self) {
                //console.log(self);
                var fle = $('.flexslider');
                if (fle.length > 0) {
                    var htm = self.data.lbhtml;
                    var heig = $('.flexslider ul li').height();
                    //console.log(heig);
                    //这里需要注意，是获取了轮播页面的高度并且在data对象中去保存
                    self.data.hei = heig;
                    //console.log(self.data.hei);
                    if (self.data.hei == 0) {
                        self.data.hei = 600;
                    }
                    var ul = $(".flexslider ul.slides");
                    var sp = $('.spring');
                    if (sp.length > 0) {
                        //console.log(sp);
                        sp.remove();
                        // var first = ul.prepend(htm);
                    }
                    var first = ul.prepend(htm);
                    //console.log(htm);
                    //console.log(self);
                    self.fun.add_css.call(self, self);
                } else {
                    //console.log("执行到了")
                    var child = $('body').children();
                    self.data.hei = 600;
                    var html = self.data.wulbhtml;
                    //无轮播添加banner
                    child.eq(10).after(html);
                    self.fun.add_css(self);
                    for (var i = 0; i < self.data.selectorDiv.length; i++) {
                        if ($(self.data.selectorDiv[i]).length > 0) {
                            $('.spring').remove();
                            $(self.data.selectorDiv[i]).after(html);
                            self.fun.add_css(self);
                            break;
                        }
                    }

                };

            },
            //获取url比较，相当于indexOf方法，判断url是否和当前窗口url相符，返回0相符，返回-1不相符
            urlHref: function (e) {//e是活动页url
                var str = location.href.toLowerCase(),
                    adap = ['www.zhongye.org.cn', 'www.ccedu24.com', 'bj.zhongyegongkao.com'];
                for (var k = 0; k < adap.length; k++) {
                    str.indexOf(adap[k]) > -1 ?
                        str = str.replace(adap[k], "bj.zhongye.net") : '';
                }
                var strLastLen = str.lastIndexOf("/"),//获取最后一个/的位置
                    strIndexof = str.indexOf('//'),//获取//的位置
                    strVal = str.substring(strIndexof + 2, strLastLen + 1),
                    len = str.indexOf('?'),
                    strArray = ['.html', '.htm'],
                    returnVal = -1,
                    strPar = -1,
                    s;
                if (len > -1) {
                    strVal = str.substring(strIndexof + 2, len);
                }
                for (var i = 0; i < strArray.length; i++) {
                    strPar = str.indexOf(strArray[i]);//拿到.html或.htm的位置，没有返回-1
                    s = str.substring(strIndexof + 2, strPar + strArray[i].length);//strPar拿到//和.之间的串
                    if (strPar > -1) {
                        break;
                    }
                }
                if (strPar > -1) {
                    if (len > -1) {
                        if (strVal == e) {
                            returnVal = 0;
                        } else {
                            returnVal = -1;
                        }
                    } else {
                        if (s == e) {
                            returnVal = 0;
                        } else {
                            returnVal = -1;
                        }
                    }
                } else {
                    if (strVal == e) {
                        returnVal = 0;
                    } else {
                        returnVal = -1;
                    }
                }
                return returnVal;
            },
            /* 单独对待一下网页轮播 */
            alongSlide: function () {
                jqFlexSlider && flexSlider && $('.flexslider').flexslider({ //只有都存在才会执行后边 flexslider 方法
                    directionNav: true,
                    pauseOnAction: false,
                    animationLoop: true,
                    slideshowSpeed: 5000,
                    after: function (slider) {
                        if (slider.currentSlide === 1) {
                            $("#mobile1").off('focus blur').on('focus blur', function (e) {
                                if (e.type === 'blur') {
                                    slider.play();
                                    console.log("play");
                                } else {
                                    slider.pause();
                                    console.log("stop");
                                }
                            });
                        }
                    },
                    start: function (slider) {
                        loopCount++;
                        if (slider.currentSlide === 0 && loopCount === 1) {
                            return;
                        }

                    }
                });
            },
            //数组去重,由于孙财政给的页面链接有好多重复的，所以用了一个数组去重
            arrremoval: function (array) {
                var temp = []; //一个新的临时数组
                for (var i = 0; i < array.length; i++) {
                    if (temp.indexOf(array[i]) == -1) {
                        temp.push(array[i]);
                    }
                }
                return temp;
            },
            //jsonp请求后的回调
            callback: function () {
                var self = this;
                var e = self.data.actUrl,
                    eLen = e.length;
                //去请求timer插件按活动时间执行插入banner插入横幅
                self.fun.get_js("//www.zhongye.net/news_skin/js/timer.js?t=201711081508", function () {
                    //console.log(self);
                    var activity_timer = new Timer({
                        id: "",
                        server: 0,
                        endtime: "2018/11/5 00:00:00", //活动开始时间
                        show: function (id, d, h, m, s, ms, nowtime) {
                            // 没到endtime时间，执行此处代码，没到活动时执行的代码
                            // $('.spring').remove();
                            self.fun.springflex();
                            // $('.activity-banner').remove();
                            // console.log(0)
                        },
                        over: function (id, d, h, m, s, ms, nowtime) {
                            //过了endtime时间，执行此处代码；
                            if (new Date(nowtime) > new Date('2018/11/12 00:00:00')) { //活动结束时间
                                //活动结束后执行的代码
                                // if (self.fun.urlHref('www.zhongye.net/wxzsjz/yishi/') > -1) {
                                //     return;
                                // }
                                // $('.spring').removeAttr("style").remove();
                                // $('.activity-banner').remove();
                                self.fun.springflex();
                            } else {
                                //过了开始时间，endtime，活动开始，执行的代码
                                //在这个里面去执行插入banner和横幅
                                for (var i = 0; i < eLen; i++) {
                                    if (self.fun.urlHref(e[i].toLowerCase()) > -1) {
                                        if ($('.spring').length == 0) {
                                            if (self.data.nothingBanner.length != 0) {//判断不加banner的页面的长度
                                                for (var v = 0; v < self.data.nothingBanner.length; v++) {//遍历不加banner的页面
                                                    if (self.fun.urlHref(self.data.nothingBanner[v]) == -1) {
                                                        self.fun.add_html(self);
                                                    }
                                                }
                                            } else {
                                                self.fun.add_html(self); // 添加banner轮播
                                            }
                                        }
                                        if ($('.hf_spring').length == 0) {
                                            var index = parseInt(Math.random() * 4);
                                            var url = window.location.href;
                                            if (self.data.nothingHenfu.length != 0) {
                                                for (var c = 0; c < self.data.nothingHenfu.length; c++) {
                                                    if (self.fun.urlHref(self.data.nothingHenfu[c]) == -1) {
                                                        if (url.indexOf('parameter=leyu11') > -1) {
                                                            self.fun.unified_banner(12, 'before', self.data.hfhtml1[index]);
                                                        } else {
                                                            self.fun.unified_banner(12, 'before', self.data.hfhtml[index]); // 添加统一横幅
                                                        }
                                                    }
                                                }
                                            } else {
                                                if (url.indexOf('parameter=leyu11') > -1) {
                                                    self.fun.unified_banner(12, 'before', self.data.hfhtml1[index]);
                                                } else {
                                                    self.fun.unified_banner(12, 'before', self.data.hfhtml[index]); // 添加统一横幅
                                                }
                                            }

                                        }

                                        self.fun.pdurl(self);
                                    }
                                }
                                self.fun.springflex();
                            }
                        }
                    });
                })
            },
            //初始化去执行函数，请求后台数据
            new_addbanner: function () {
                var self = this;
                var url = win.location.href;
                //console.log(url);
                //console.log(url.indexOf('www.zhongye.net'));
                if (url.indexOf('bj.zhongye.net') > -1 || url.indexOf('www.ccedu24.com') > -1 || url.indexOf('www.zhongye.org.cn') > -1 || url.indexOf('bjpz.zhongye.net') > -1) {
                    //console.log(1);
                    self.fun.get_js(self.data.address[1], function () {
                        self.fun.callback.call(self);
                    })
                }
            },
            //判断跳转项目页，出现乐语
            pdurl: function (self) {

                var url = win.location.search;
                //如果含有活动url传参就是跳转乐语
                if (url.indexOf("parameter=leyu11") > -1) {
                    $('.spring,.hf_spring').on('click', function () {
                        $('#leyuOnclick')[0].click();
                    })
                } else {
                    //否则是去遍历后台数据拿到后台的乐语和大区id并且在点击的时候判断是跳转乐语或者跳转活动页面
                    //变量json拿到后台传过来数据
                    var json = callbackJson;
                    var eLen = json.DataObj;
                    for (var i = 0; i < eLen.length; i++) {
                        var o = eLen[i];
                        //遍历后台数据
                        if (self.fun.urlHref(o.url.toLowerCase()) > -1) {
                            // console.log(o.url);
                            var url = location.href;
                            // console.log(LikeClass, url);
                            var leyuId = o.leyuId;
                            var leyuGroupId = o.leyuGroupId;
                            //给活动banner绑定点击事件，逻辑是先判断北京在判断考研，在判断金融家，剩下的都在网校，根据likeclass，和daquid中去判断跳转那个页面
                            $('.spring,.hf_spring').on('click', function () {
                                console.log(o);
                                var LikeClass = $('#LikeClass').val();
                                var dqId = $('#daquid').val();
                                if (url.indexOf('bj.zhongye.net') > -1 || url.indexOf('www.ccedu24.com') > -1 || url.indexOf('www.zhongye.org.cn') > -1) {
                                    var href = self.data.wdhproject[6] + '?lyid=' + o.leyuId + '&lyGroupId=' + o.leyuGroupId
                                } else if (url.indexOf('www.zhongyekaoyan.com') > -1) {
                                    var href = self.data.wdhproject[7] + '?lyid=' + leyuId + '&lyGroupId=' + leyuGroupId
                                } else if (url.indexOf('jinrongjia.zhongye.net') > -1) {
                                    var href = self.data.wdhproject[9] + '?lyid=' + leyuId + '&lyGroupId=' + leyuGroupId
                                } else {
                                    if (LikeClass == 3 || LikeClass == 4 || LikeClass == 5 || LikeClass == 6 || LikeClass == 201 || LikeClass == 1325 || LikeClass == 1373 || LikeClass == 1398 || LikeClass == 1083 || LikeClass == 1080) {
                                        if (url.indexOf('nj') > -1 && dqId == 3377) {
                                            var href = self.data.wdhproject[0] + '?lyid=' + leyuId + '&lyGroupId=' + leyuGroupId
                                        } else if (url.indexOf('sh') > -1 && dqId == 3378) {
                                            var href = self.data.wdhproject[1] + '?lyid=' + leyuId + '&lyGroupId=' + leyuGroupId
                                        } else {
                                            var href = self.data.wdhproject[4] + '?lyid=' + leyuId + '&lyGroupId=' + leyuGroupId
                                        }
                                    } else if (LikeClass == 228 || LikeClass == 1173 || LikeClass == 1347) {
                                        var href = self.data.wdhproject[8] + '?lyid=' + leyuId + '&lyGroupId=' + leyuGroupId
                                    } else if (LikeClass == 1414 || LikeClass == 1415) {
                                        var href = self.data.wdhproject[5] + '?lyid=' + leyuId + '&lyGroupId=' + leyuGroupId
                                    } else if (LikeClass == 1019) {
                                        var href = self.data.wdhproject[5] + '?lyid=' + leyuId + '&lyGroupId=' + leyuGroupId
                                    } else if (LikeClass == 1008 || LikeClass == 1193 || LikeClass == 1512 || LikeClass == 1057 || LikeClass == 69) {
                                        var href = self.data.wdhproject[2] + '?lyid=' + leyuId + '&lyGroupId=' + leyuGroupId
                                    } else {
                                        var href = self.data.wdhproject[10] + '?lyid=' + leyuId + '&lyGroupId=' + leyuGroupId
                                    }
                                }
                                var html = '<a target="_blank" href = "javascript:void(0);" id ="urlJump" style = "display:none;" > url跳转按钮 </a>'
                                $('body,html').append(html);
                                $('#urlJump').attr('href', href);
                                $('#urlJump')[0].click();
                            })
                        }
                    }
                }
            },
            //调用班型使用，一般情况下遇不到
            banxing: function () {
                var url = window.location.href;
                var that = this;
                var script = document.getElementsByTagName("script"),
                    scrTrue = false;
                for (var i = 0; i < script.length; i++) {
                    // console.log(script[i])
                    if (script[i].src.indexOf('/news_skin/js/timer.js') > -1) {
                        // console.log(script[i])
                        scrTrue = true;
                        // console.log(scrTrue);
                        // var script1 = null,
                        //     xhead = document.getElementsByTagName("head")[0];
                        // script1 = document.createElement("script");
                        // script1.type = "text/javascript";
                        // script1.src = 'www.zhongye.net';
                        // console.log('看看执行了几次 ');
                        // console.log(156)
                        // xhead.insertBefore(script1, xhead.firstChild);
                        // scrTrue = false;



                    } else {
                        // that.fun.get_js('/news_skin/js/timer.js?t=201711081508', function () {
                        //     var activity_timer = new Timer({
                        //         id: "",
                        //         server: 1,
                        //         endtime: "2018/11/5 00:00:00", //活动开始时间
                        //         show: function (id, d, h, m, s, ms, nowtime) {
                        //             if ($('#iframepage').length > 0) {
                        //                 if ($('#s11banxing').length == 0) {
                        //                     that.fun.s11banxing(url);
                        //                 }
                        //             }
                        //         },
                        //         over: function (id, d, h, m, s, ms, nowtime) {
                        //             //过了endtime时间，执行此处代码；
                        //             if (new Date(nowtime) > new Date('2018/11/12 00:00:00')) { //活动结束时间

                        //             } else {
                        //                 //过了开始时间，endtime，活动开始，执行的代码
                        //                 if ($('#iframepage').length > 0) {
                        //                     if ($('#s11banxing').length == 0) {
                        //                         that.fun.s11banxing(url);
                        //                     }
                        //                 }

                        //             }
                        //         }
                        //     });
                        // })
                    }
                }
                if (scrTrue) {
                    var activity_timer = new Timer({
                        id: "",
                        server: 1,
                        endtime: "2018/11/5 00:00:00", //活动开始时间
                        show: function (id, d, h, m, s, ms, nowtime) {
                            if ($('#iframepage').length > 0) {
                                if ($('#s11banxing').length == 0) {
                                    that.fun.s11banxing(url);
                                }
                            }
                        },
                        over: function (id, d, h, m, s, ms, nowtime) {
                            if ($('#iframepage').length > 0) {
                                if ($('#s11banxing').length == 0) {
                                    that.fun.s11banxing(url);
                                }
                            }
                        }
                    });
                }

            },
            //去判定需要改班型的页面
            s11banxing: function (url) {
                if (url.indexOf('bj_yjjzs_sem_pc/') > -1 || url.indexOf('bj_yjjzs_sem_pc/tiaojian/') > -1 || url.indexOf('bj_yjjzs_sem_pc/ziliao/') > -1 || url.indexOf('bj_yjjzs_sem_pc/') > -1) {

                    $('#iframepage').hide();
                    $('#iframepage').after('<iframe src="/zsjz/class/d11banxing_yj/" width="100%" height="100%" id="s11banxing" name="iframepage" data-iframe></iframe>');
                    setTimeout(function () {
                        ZY.util.iframeId("s11banxing");
                    }, 50);

                } else if (url.indexOf('zsjz/ej_bt/') > -1 || url.indexOf('bj_ejjzs_sem_pc/baokaoxinxi/') > -1 || url.indexOf('bj_ejjzs_sem_pc/shijian/') > -1 || url.indexOf('bj_ejjzs_sem_pc/jiaocai/') > -1 || url.indexOf('bj_ejjzs_sem_pc/tiaojian/') > -1 || url.indexOf('bj_ejjzs_sem_pc/new/') > -1 || url.indexOf('bj_ejjzs_sem_pc/ziliao/') > -1) {

                    $('#iframepage').hide();
                    $('#iframepage').after('<iframe src="/zsjz/class/d11banxing_ej/" width="100%" height="100%" id="s11banxing" name="iframepage" data-iframe></iframe>');
                    setTimeout(function () {
                        ZY.util.iframeId("s11banxing");
                    }, 50);

                } else if (url.indexOf('bj_aqgcs_sem_pc/btg/') > -1 || url.indexOf('bj_ejjzs_sem_pc/baokaoxinxi/') > -1 || url.indexOf('bj_aqgcs_sem_pc/bkzl/') > -1 || url.indexOf('bj_aqgcs_sem_pc/zc/  ') > -1 || url.indexOf('bj_aqgcs_sem_pc/btg/') > -1) {

                    $('#iframepage').hide();
                    $('#iframepage').after('<iframe src="/zsjz/class/d11banxing_aq/" width="100%" height="100%" id="s11banxing" name="iframepage" data-iframe></iframe>');
                    setTimeout(function () {
                        ZY.util.iframeId("s11banxing");
                    }, 50);

                } else if (url.indexOf('bj_yjxfgcs_sem_pc/') > -1 || url.indexOf('bj_yjxfgcs_sem_pc/btg/') > -1 || url.indexOf('bj_yjxfgcs_sem_pc/btg/') > -1) {

                    $('#iframepage').hide();
                    $('#iframepage').after('<iframe src="/zsjz/class/d11banxing_xf/" width="100%" height="100%" id="s11banxing" name="iframepage" data-iframe></iframe>');
                    setTimeout(function () {
                        ZY.util.iframeId("s11banxing");
                    }, 50);

                } else if (url.indexOf('zsjz/zjgcs_bt/') > -1 || url.indexOf('bj_zjgcs_sem_pc/news_ceshi/') > -1) {

                    $('#iframepage').hide();
                    $('#iframepage').after('<iframe src="/zsjz/class/d11banxing_zj/" width="100%" height="100%" id="s11banxing" name="iframepage" data-iframe></iframe>');
                    setTimeout(function () {
                        ZY.util.iframeId("s11banxing");
                    }, 50);

                } else { }

            }
        }
    };
    win.ACT = function (obj) {
        new activity(obj);
    }
})(window, $)
var act = ACT({
    //轮播banner
    lbhtml: "<li class='spring'><div class='wrapper' data-leyu style='cursor:pointer'></div></li>",
    // 没有轮播的banner
    wulbhtml: "<div class='spring'><div class='wrapper' data-leyu style='cursor:pointer'></div></div>",
    //横幅有按钮
    hfhtml: ['<div target="_blank" class = "hf_spring" style = "background: url(//www.zhongye.net/active/img/henfu.jpg) no-repeat center center;height: 100px;cursor:pointer" ></div>',
        '<div target="_blank" class = "hf_spring" style = "background: url(//www.zhongye.net/active/img/henfu1.jpg) no-repeat center center;height: 100px;cursor:pointer" ></div>',
        '<div target="_blank" class = "hf_spring" style = "background: url(//www.zhongye.net/active/img/henfu2.jpg) no-repeat center center;height: 100px;cursor:pointer" ></div>',
        '<div target="_blank" class = "hf_spring" style = "background: url(//www.zhongye.net/active/img/henfu3.jpg) no-repeat center center;height: 100px;cursor:pointer" ></div>'
    ],
    //横幅没有按钮
    hfhtml1: ['<div target="_blank" class = "hf_spring" style = "background: url(//www.zhongye.net/active/img/henfu11.jpg) no-repeat center center;height: 100px;cursor:pointer" ></div>',
        '<div target="_blank" class = "hf_spring" style = "background: url(//www.zhongye.net/active/img/henfu21.jpg) no-repeat center center;height: 100px;cursor:pointer" ></div>',
        '<div target="_blank" class = "hf_spring" style = "background: url(//www.zhongye.net/active/img/henfu31.jpg) no-repeat center center;height: 100px;cursor:pointer" ></div>',
        '<div target="_blank" class = "hf_spring" style = "background: url(//www.zhongye.net/active/img/henfu41.jpg) no-repeat center center;height: 100px;cursor:pointer" ></div>'
    ],
    //插入banner的位置计算
    selectorDiv: ['.header', '.nav', '.nav2', '.banner', '.head', '.titLog'],
    //jsonp后台请求数据
    address: [
        "//tg.zhongye.net/jsonadmin/json.asp?leixing=wxpc&v=" + new Date().getTime(),
        "//tg.zhongye.net/jsonadmin/json.asp?leixing=mspc&v=" + new Date().getTime(),
        "//tg.zhongye.net/jsonadmin/json.asp?leixing=kypc&v=" + new Date().getTime(),
        "//tg.zhongye.net/jsonadmin/json.asp?leixing=gkpc&v=" + new Date().getTime(),
        "//tg.zhongye.net/jsonadmin/json.asp?leixing=kymb&v=" + new Date().getTime(),
        "//tg.zhongye.net/jsonadmin/json.asp?leixing=kymb&v=" + new Date().getTime(),
        "//tg.zhongye.net/jsonadmin/json.asp?leixing=kymb&v=" + new Date().getTime(),
        "//tg.zhongye.net/jsonadmin/json.asp?leixing=kymb&v=" + new Date().getTime(),
    ],
    //参与活动url
    actUrl: [
        'www.zhongye.net/wxq_yjjzs_sem_pc/',
        'www.zhongye.net/wxq_ejjzs_sem_pc/',
        'bj.zhongye.net/bj_ejjzs_sem_pc/19new/',
        'www.zhongye.net/wxq_zjgcs_sem_pc/new/',
        'www.zhongye.net/wxq_aqgcs_sem_pc/zonghe/',
        'www.zhongye.net/wxq_jlgcs_sem_pc/zh/',
        'www.zhongye.net/wxq_xfgcs_sem_pc/xin/',
        'www.zhongye.net/wxq_zcjzs_sem_pc/yjbaoming/',
        'www.zhongye.net/wxq_zcjzs_sem_pc/erbaoming/',
        'www.zhongye.net/wxq_zcdqgcs_sem_pc/new2/',
        'www.zhongye.net/wxq_zckjs_sem_pc/peixunban/',
        'www.zhongye.net/wxzsjz/chujikuaiji_zonghe/',
        'www.zhongye.net/wxq_zjkjzc_sem_pc/zonghe/',
        'www.zhongye.net/wxq_jjs_sem_pc/xzh/',
        'www.zhongye.net/wxq_sws_sem_pc/2019peixun/',
        'www.zhongye.net/wxq_flzyks_sem_pc/2019peixun/',
        'www.zhongye.net/wxq_zyyaos_sem_pc/zonghe/',
        'www.zhongye.net/wxq_zyyis_sem_pc/zonghe/',
        'www.zhongye.net/wxq_hszyzgz_sem_pc/zonghe/',
        'www.zhongyekaoyan.com/wxq_mba_sem_pc/',
        'www.zhongyekaoyan.com/wxq_mpa_sem_pc/',
        'www.zhongyekaoyan.com/wxq_mpacc_sem_pc/',
        'www.zhongyekaoyan.com/wxq_emba_sem_pc/',
        'www.zhongyekaoyan.com/wxq_kyggk_sem_pc/puyan/',
        'www.zhongyegongkao.com/wxq_gwy_sem_pc/zsjz/gongwuyuan_gkbs/',
        'jinrongjia.zhongye.net/wxq_yhzpks_sem_pc/zx/',
        'jinrongjia.zhongye.net/wxq_yhcyzgz_sem_pc/zx/',
        'jinrongjia.zhongye.net/wxq_zqcyzgz_sem_pc/zx/',
        'bj.zhongye.net/bj_yjjzs_sem_pc/new/',
        'bj.zhongye.net/bj_ejjzs_sem_pc/new/',
        'bj.zhongye.net/bj_zjgcs_sem_pc/news_ceshi/',
        'bj.zhongye.net/bj_aqgcs_sem_pc/news/',
        'bj.zhongye.net/bj_yjxfgcs_sem_pc/',
        'bj.zhongye.net/bj_zjy_sem_pc/',
        'bj.zhongye.net/bj_zly_sem_pc_cs/',
        'bj.zhongye.net/bj_cly_sem_pc/',
        'bj.zhongye.net/bj_jxy_sem_pc/',
        'bj.zhongye.net/bj_sgy_sem_pc_cs/',
        'bj.zhongye.net/bj_zhily_sem_pc_cs/',
        'bj.zhongye.net/bj_syy_sem_pc/',
        'bj.zhongye.net/bj_zjy_sem_pc/',
        'bj.zhongye.net/bj_hty_sem_pc/',
        'bj.zhongye.net/bj_aqy_sem_pc_cs/',
        'bj.zhongye.net/bj_cely_sem_pc/',
        'bj.zhongye.net/bj_ldlgly_sem_pc/',
        'bj.zhongye.net/bj_xfy_sem_pc/',
        'bj.zhongye.net/bj_jszgzks_sem_pc/ceshi/',
        'bj.zhongye.net/bj_gkgwy_sem_pc/news/',
        'www.zhongye.net/nj_yjjzs_sem_pc/new/',
        'www.zhongye.net/nj_ejjzs_sem_pc/new1/',
        'www.zhongye.net/nj_aqgcs_sem_pc/news',
        'www.zhongye.net/nj_yjxfgcs_sem_pc/',
        'www.zhongye.net/nj_jlgcs_sem_pc/',
        'www.zhongye.net/nj_aqgcs_sem_pc/news',
        'www.zhongye.net/sh_yjjzs_sem_pc/new/',
        'www.zhongye.net/sh_ejjzs_sem_pc/new/',
        'www.zhongye.net/sh_zjgcs_sem_pc/news/',
        'www.zhongye.net/sh_jlgcs_sem_pc/',
        'www.zhongye.net/sh_yjxfgcs_sem_pc/',
        'www.zhongye.net/sh_aqgcs_sem_pc/news/',
        'www.zhongye.net/wxq_yjjzs_sem_pc/',
        'www.zhongye.net/wxq_ejjzs_sem_pc/',
        'www.zhongye.net/wxq_zjgcs_sem_pc/new/',
        'www.zhongye.net/wxq_aqgcs_sem_pc/xinzonghe/',
        'www.zhongye.net/wxq_jlgcs_sem_pc/zh/',
        'www.zhongye.net/wxq_xfgcs_sem_pc/xin/',
        'www.zhongye.net/wxzsjz/bim/',
        'www.zhongye.net/wxzsjz/zixun/',
        'www.zhongye.net/wxq_zcjzs_sem_pc/yjbaoming/',
        'www.zhongye.net/wxq_zcjzs_sem_pc/ejbaoming/',
        'www.zhongye.net/wxq_zcdqgcs_sem_pc/new2/',
        'www.zhongye.net/wxzsjz/anpingshi/',
        'm.zhongye.net/wxq_zbs_pz_m/',
        'www.zhongye.net/wxq_zyyaos_sem_pc/bk/',
        'www.zhongye.net/wxq_zyyis_sem_pc/zonghe/',
        'www.zhongye.net/wxq_hszyzgz_sem_pc/zonghe/',
        'www.zhongye.net/wxq_flzyks_sem_pc/2019peixun/',
        'www.zhongye.net/wxzsjz/zhukuai_zonghe/',
        'www.zhongye.net/wxzsjz/chujikuaiji_zonghe/',
        'www.zhongye.net/wxq_zjkjzc_sem_pc/zonghe/',
        'www.zhongye.net/wxq_jjs_sem_pc/xzh/',
        'www.zhongye.net/wxq_sws_sem_pc/2019peixun/',
        'jinrongjia.zhongye.net/wxq_yhzpks_sem_pc/',
        'jinrongjia.zhongye.net/wxq_yhzpks_sem_pc/',
        'jinrongjia.zhongye.net/wxq_yhcyzgz_sem_pc/zx/',
        'jinrongjia.zhongye.net/wxq_zqcyzgz_sem_pc/zx/',
        'www.zhongyegongkao.com/course/buy/',
        'bj.zhongye.net/bj_yjjzs_sem_pc/',
        'bj.zhongye.net/zsjz/ej_bt/',
        'bj.zhongye.net/bj_yjxfgcs_sem_pc/btg/',
        'bj.zhongye.net/zsjz/jianli/',
        'bj.zhongye.net/bj_aqgcs_sem_pc/btg/',
        'bj.zhongye.net/zsjz/zixun/baidu/',
        'bj.zhongye.net/zsjz/jianlishigwz/',
        'bj.zhongye.net/bj_zjy_sem_pc/',
        'bj.zhongye.net/zsjz/bim/',
        'm.zhongye.org.cn/ziliaoyuan/',
        'bj.zhongye.net/bj_cly_sem_pc/',
        'bj.zhongye.net/bj_jxy_sem_pc/',
        'bj.zhongye.net/bj_sgy_sem_pc/',
        'bj.zhongye.net/bj_zhily_sem_pc/',
        'bj.zhongye.net/bj_syy_sem_pc/',
        'bj.zhongye.net/bj_jly_sem_pc/',
        'bj.zhongye.net/bj_hty_sem_pc/',
        'bj.zhongye.net/bj_aqy_sem_pc/',
        'bj.zhongye.net/bj_cely_sem_pc/',
        'bj.zhongye.net/bj_ldlgly_sem_pc/',
        'bj.zhongye.net/bj_xfy_sem_pc/',
        'bj.zhongye.net/zsjz/jianzhushi/',
        'bj.zhongye.net/zsjz/jianzhushi/',
        'bj.zhongye.net/bj_jszgzks_sem_pc/',
        'bj.zhongye.net/zsjz/yzz/',
        'bj.zhongye.net/zsjz/jiaoshi/',
        'bj.zhongye.net/zsjz/byy/',
        'bj.zhongye.net/zsjz/zjgcs_bt/',
        'jinrongjia.zhongye.net/wxq_yhzpks_sem_pc/',
        'bj.zhongye.net/bj_jjs_sem_pc/',
        'bj.zhongye.net/zsjz/zhichengyy/',
        'bj.zhongye.net/bj_gkgwy_sem_pc/',
        'www.zhongye.net/nj_yjjzs_sem_pc/new/',
        'www.zhongye.net/wxzsjz/nj/erjian/',
        'www.zhongye.net/wxzsjz/nj/zaojia/',
        'www.zhongye.net/wxzsjz/nj/xiaofanggcs/',
        'www.zhongye.net/wxzsjz/nj/anquanshi/',
        'www.zhongye.net/sh_yjjzs_sem_pc/new/',
        'www.zhongye.net/sh/Ntuiguang/erjian/',
        'www.zhongye.net/sh/Ntuiguang/zaojia/',
        'www.zhongye.net/sh/Ntuiguang/xiaofanggcs/',
        'www.zhongye.net/sh/Ntuiguang/aqgcs/',
        'www.zhongye.net/wxq_yjjzs_sem_pc/',
        'www.zhongye.net/wxq_ejjzs_sem_pc/',
        'www.zhongye.net/wxq_zjgcs_sem_pc/new/ ',
        'www.zhongye.net/wxq_aqgcs_sem_pc/zonghe/ ',
        'www.zhongye.net/wxq_jlgcs_sem_pc/zh/',
        'www.zhongye.net/wxq_xfgcs_sem_pc/',
        'www.zhongye.net/wxzsjz/yiji_jianzhushi/baoming/',
        'www.zhongye.net/wxzsjz/erji_jianzhushi/baoming/',
        'www.zhongye.net/wxq_zcdqgcs_sem_pc/new2/',
        'www.zhongye.net/wxzsjz/zhukuai_zonghe/',
        'www.zhongye.net/wxzsjz/chujikuaiji_zonghe/',
        'www.zhongye.net/wxq_zjkjzc_sem_pc/zonghe/',
        'www.zhongye.net/wxq_jjs_sem_pc/xzh/',
        'www.zhongye.net/wxq_sws_sem_pc/zonghe1/',
        'www.zhongye.net/wxq_flzyks_sem_pc/zonghe1/',
        'www.zhongye.net/wxq_zyyaos_sem_pc/bk/',
        'www.zhongye.net/wxq_zyyis_sem_pc/zonghe/',
        'www.zhongye.net/wxq_hszyzgz_sem_pc/zonghe/',
        'www.zhongyekaoyan.com/wxq_mba_sem_pc/',
        'www.zhongyekaoyan.com/wxq_mpa_sem_pc/',
        'www.zhongyekaoyan.com/wxq_mpacc_sem_pc/',
        'www.zhongyekaoyan.com/wxq_emba_sem_pc/',
        'www.zhongyekaoyan.com/wxq_kyggk_sem_pc/zaizhi/',
        'www.zhongyegongkao.com/wxq_gwy_sem_pc/zsjz/gongwuyuan_gkbs/',
        'jinrongjia.zhongye.net/wxq_yhzpks_sem_pc/zx/',
        'jinrongjia.zhongye.net/wxq_yhcyzgz_sem_pc/zx/',
        'jinrongjia.zhongye.net/wxq_zqcyzgz_sem_pc/zx/',
        'bj.zhongye.net/bj_aqgcs_sem_pc/bktj/',
        'bj.zhongye.net/bj_yjxfgcs_sem_pc/',
        'bj.zhongye.net/bj_zjy_sem_pc_zc/',
        'bj.zhongye.net/bj_zly_sem_pc_zc/',
        'bj.zhongye.net/bj_cly_sem_pc_zc/',
        'bj.zhongye.net/bj_aqy_sem_pc/',
        'bj.zhongye.net/bj_sgy_sem_pc_zc/',
        'bj.zhongye.net/bj_zhily_sem_pc_zc/',
        'bj.zhongye.net/bj_syy_sem_pc_zc/',
        'bj.zhongye.net/bj_jly_sem_pc_zc/',
        'bj.zhongye.net/bj_hty_sem_pc_zc/',
        'bj.zhongye.net/bj_aqy_sem_pc_zc/',
        'bj.zhongye.net/bj_cely_sem_pc_zc/',
        'bj.zhongye.net/bj_ldlgly_sem_pc_zc/',
        'bj.zhongye.net/bj_xfy_sem_pc_zc/',
        'bj.zhongye.net/bj_jszgzks_sem_pc/new/',
        'bj.zhongye.net/bj_gkgwy_sem_pc/',
        'www.zhongye.net/nj_yjjzs_sem_pc/new/',
        'www.zhongye.net/nj_ejjzs_sem_pc/new1/',
        'www.zhongye.net/nj_zjgcs_sem_pc/news/',
        'www.zhongye.net/nj_yjxfgcs_sem_pc/',
        'www.zhongye.net/nj_aqgcs_sem_pc/tiaojian/',
        'www.zhongye.net/sh_yjjzs_sem_pc/new/',
        'www.zhongye.net/sh_ejjzs_sem_pc/new/',
        'www.zhongye.net/sh_zjgcs_sem_pc/news/',
        'www.zhongye.net/sh_yjxfgcs_sem_pc/',
        'www.zhongye.net/sh_aqgcs_sem_pc/tiaojian/',
        'www.zhongye.net/yongsheng/shuangshiyi/',
        'bj.zhongye.net/yongsheng/'
    ],
    //进入活动分会场页面
    wdhproject: [
        '//www.zhongye.net/active/2018Double_Eleven/parallel_sessions_wdh/msnjwdh/',
        '//www.zhongye.net/active/2018Double_Eleven/parallel_sessions_wdh/msshwdh/',
        '//www.zhongye.net/active/2018Double_Eleven/parallel_sessions_wdh/wxckwdh/',
        '//www.zhongye.net/active/2018Double_Eleven/parallel_sessions_wdh/wxfkwdh/',
        '//www.zhongye.net/active/2018Double_Eleven/parallel_sessions_wdh/wxgcwdh/',
        '//www.zhongye.net/active/2018Double_Eleven/parallel_sessions_wdh/wxgklwdh/',
        '//www.zhongye.net/active/2018Double_Eleven/parallel_sessions_wdh/bjmswdh/',
        '//www.zhongye.net/active/2018Double_Eleven/parallel_sessions_wdh/kywdh/',
        '//www.zhongye.net/active/2018Double_Eleven/parallel_sessions_wdh/yywdh/',
        '//jinrongjia.zhongye.net/active/',
        '//www.zhongye.net/active/2018Double_Eleven/Main_venue/'
    ],
    //如果不需要上轮播的化，只需要吧不需要上轮播的链接写在这个数组里即可
    nothingBanner: [

    ],
    //如果不上横幅，则只需要吧不上横幅的链接写在这里即可
    nothingHenfu: [

    ]

})